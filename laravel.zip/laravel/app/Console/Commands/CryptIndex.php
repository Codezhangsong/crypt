<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use PHPMailer\PHPMailer\PHPMailer;

class CryptIndex extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'greedy:index';
    protected $url = "https://api.alternative.me/fng/";
    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        while (true){
            $res = file_get_contents($this->url);
            $data = json_decode($res,true);

            if(isset($data['data'][0]['value'])){
                $index = $data['data'][0]['value'];
                $value_classification = $data['data'][0]['value_classification'];
                $timestamp = $data['data'][0]['timestamp'];
                $time_until_update = $data['data'][0]['time_until_update'];
                if(!file_exists('crypt_index.json')){
                    $json_strings  = [
                        [
                            date("Y-m-d H:i:s",$timestamp)=>$index
                        ]
                    ];
                    file_put_contents("crypt_index.json",json_encode($json_strings));//写入
                }else{
                    $json_string = file_get_contents("crypt_index.json");//
                    $old_list = json_decode($json_string,true);
                    if(count($old_list)>100){
                        $old_list = [];
                    }
                    array_push($old_list,[
                        date("Y-m-d H:i:s",$timestamp)=>$index
                    ]);
                    file_put_contents("crypt_index.json",json_encode($old_list));//写入
                }
                $content = "当前贪婪指数为:{$index},贪婪级别为:{$value_classification}";
                $this->sendMail($content);
            }
            echo '睡眠'.$time_until_update.'秒';
            sleep($time_until_update);
        }
        return 0;
    }

    public function sendMail($content)
    {
        $mail = new PHPMailer(true);                              // Passing `true` enables exceptions
        try {
            //服务器配置
            $mail->CharSet ="UTF-8";                     //设定邮件编码
            $mail->SMTPDebug = 0;                        // 调试模式输出
            $mail->isSMTP();                             // 使用SMTP
            $mail->Host = 'smtp.gmail.com';                // SMTP服务器
            $mail->SMTPAuth = true;                      // 允许 SMTP 认证
            $mail->Username = 'g491852912@gmail.com';                // SMTP 用户名  即邮箱的用户名
            $mail->Password = 'vewwaqoyedmduaxj';             // SMTP 密码  部分邮箱是授权码(例如163邮箱) Gmail是应用专用密码
            $mail->SMTPSecure = 'ssl';                    // 允许 TLS 或者ssl协议
            $mail->Port = 465;                            // 服务器端口 25 或者465 具体要看邮箱服务器支持

            $mail->setFrom(env('MAIL_ADDR'), 'Crypt');  //发件人
            $mail->addAddress(env('MAIL_ADDR'), 'Leo');  // 收件人
            $mail->addReplyTo(env('MAIL_ADDR'), 'Crypt'); //回复的时候回复给哪个邮箱 建议和发件人一致

            //发送附件
            // $mail->addAttachment('../xy.zip');         // 添加附件
            // $mail->addAttachment('../thumb-1.jpg', 'new.jpg');    // 发送附件并且重命名

            //Content
            $mail->isHTML(true);                                  // 是否以HTML文档格式发送  发送后客户端可直接显示对应HTML内容
            $mail->Subject = '贪婪指数' . time();
            $mail->Body    = "<h2>{$content}<h2>" . date('Y-m-d H:i:s');
            $mail->AltBody = '如果邮件客户端不支持HTML则显示此内容';
            $mail->send();
        } catch (\Exception $e) {
            echo '邮件发送失败: ', $mail->ErrorInfo;
        }
        return true;
    }
}
